# Detectron Homework > 2022-09-02 10:35am
https://universe.roboflow.com/object-detection/detectron-homework

Provided by Roboflow
License: CC BY 4.0

